<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * @subpackage	Rest API
 * @category	Controller
 */
require APPPATH . '/libraries/webservices/REST_Controller.php';
require APPPATH . '/libraries/webservices/Format.php';
require APPPATH . '/libraries/webservices/Message.php';

class Webservices extends REST_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('webservices_mod');
    }

    public function index_post() {
        print_r("ffgfgg");
    }


    



  
     //=============================================End of the Code================================================== 

}
