<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Auth Model 
 *
 * @package     Auth
 * @subpackage  Models
 * @category    Authentication 
 * @author      Lovekesh Singh
 * @website     https://www.a1vacationhomes.com
 * @company     A1vacationhomes Inc
 * @since       Version 1.0
 */

class Webservices_mod extends CI_Model {
    /**
     * Constructor
     */
    function __construct() {
        parent::__construct();
        $this->load->library('upload');
        $this->load->library('image_lib');
    } 
} 
?>