<?php

//Message key start

$lang['error_login']   								= 	"Username & Password are not valid!";
$lang['ip_error'] 	   								= 	"Sorry your IP address has been blocked";
$lang['error_email']                                =	"Your Email is incorrect!";
$lang['network_error']                              =	"You are not authorize to login outside the network.";
$lang['username']                                   =	"Username";
$lang['password']                                   =	"Password";
$lang['sign_in']                                    =	"Sign In";
$lang['login']                                      =	"Login";
$lang['remember']                                   =	"Remember";
$lang['enter_username_and_password']                =	"Enter Username and Password";
$lang['forgot_password']                            =	"Forgot Password";
$lang['your_account_has_been_inactive']				=	"Your account has been inactive";
$lang['invalid_login_credidential']	                =	"Invalid Login Credentials";
$lang['forget']                                     =	"Forget";
$lang['o_tutor']               	 					=   "O-TUTOR";
//validation msg
$lang['enter_user_name'] 							= 	"Please Enter username";
$lang['enter_password'] 							= 	"Please Enter psssword";
$lang['request_new_password'] 						= 	"Request New Password";
$lang['return_to_login']							=	"Return To Login";
$lang['enter_your_email_address_below']				=	"Enter your e-mail address below";
$lang['enter_your_email_address']					=	"Enter your valid e-mail address";
$lang['request_new_password']						=	"Request New Password";
$lang['email_address'] 								= 	"E-mail Address";
//Message key End

$lang['regarding_messg']							=	"Regarding:Password Recovery";
$lang['email_exist_error'] 							= 	"Email address exist ,please enter another email address";
$lang['username_exist_error']						= 	"Username exist,please enter another username";
$lang['change_password_email_subject']				=	"Your Password has been changed successfully";
$lang['you_requested_new_password']					=	"You have requested a new password for Hare";
$lang['click_here_login']							=	"Click here to login";
$lang['support_email_id']							=	"support@websitename.com";
$lang['your_username']								=	"Your Username";
$lang['hello']										=	"Hello";
$lang['your_password_send_email']					= 	"Your password has been send to your Email Address";
$lang['you_not_registered_yet']						= 	"You are not registered yet, Retry or register as a new member";
$lang['account_under_email_varification']			=	"your account is under email verification";
$lang['admin_account_inactive']						=	"Your Admin's account has been inactive.";
$lang['invalid_captcha']							=	"Please Enter a valid captcha";
$lang['captcha']                                    =   "Captcha";
$lang['E-mail_address']                             =   "E-mail_address";